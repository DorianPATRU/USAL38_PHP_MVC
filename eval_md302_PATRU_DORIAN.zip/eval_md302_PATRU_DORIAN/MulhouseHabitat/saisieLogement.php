<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saisie d'un logement</title>
</head>
<body>
    <form action="ajouterLogement.php" method="post" enctype="multipart/form-data">
        <table>
            <tr>
                <td>Type de logement :</td>
                <td><input type="text" name="housing_type"></td>
            </tr>
            <tr>
                <td>Code postal :</td>
                <td><input type="text" name="housing_postcode"></td>
            </tr>
            <tr>
                <td>Ville :</td>
                <td><input type="text" name="housing_city"></td>
            </tr>
            <tr>
                <td>Adresse :</td>
                <td><input type="text" name="housing_address"></td>
            </tr>
            <tr>
                <td>Nombre de pièces :</td>
                <td><input type="text" name="housing_piecesnumber"></td>
            </tr>
            <tr>
                <td>Surface :</td>
                <td><input type="text" name="housing_surface"></td>
            </tr>
            <tr>
                <td>Loyer :</td>
                <td><input type="text" name="housing_rent"></td>
            </tr>
            <tr>
                <td>Disponible :</td>
                <td><input type="text" name="housing_available"></td>
            </tr>
            <tr>
                <td><input type="submit" value="Enregistrer"></td>
            </tr>
        </table>
    </form>
</body>
</html>