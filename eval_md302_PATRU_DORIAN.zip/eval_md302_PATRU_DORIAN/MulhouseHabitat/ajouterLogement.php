<?php

require_once("connexion.php");

$housing_type = $_POST['housing_type'];
$housing_postcode = $_POST['housing_postcode'];
$housing_city = $_POST['housing_city'];
$housing_address = $_POST['housing_address'];
$housing_piecesnumber = $_POST['housing_piecesnumber'];
$housing_surface = $_POST['housing_surface'];
$housing_rent = $_POST['housing_rent'];
$housing_available = $_POST['housing_available'];

$req = "INSERT INTO housing(housing_type,housing_postcode,housing_city,housing_address,housing_piecesnumber,housing_surface,
housing_rent,housing_available) 
VALUES ('$housing_type','$housing_postcode','$housing_city','$housing_address','$housing_piecesnumber',
'$housing_surface','$housing_rent','$housing_available')";

if ($conn->query($req) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $req . "<br>" . $conn->error;
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajout des logements</title>
</head>
<body>
    <table border="1">
        <tr>
            <td>Type de logement :</td>
            <td><?php echo ($housing_type) ?></td>
        </tr>
        <tr>
            <td>Code postal :</td>
            <td><?php echo ($housing_postcode) ?></td>
        </tr>
        <tr>
            <td>Ville :</td>
            <td><?php echo ($housing_city) ?></td>
        </tr>
        <tr>
            <td>Adresse :</td>
            <td><?php echo ($housing_address) ?></td>
        </tr>
        <tr>
            <td>Nombre de pièces :</td>
            <td><?php echo ($housing_piecesnumber) ?></td>
        </tr>
        <tr>
            <td>Surface :</td>
            <td><?php echo ($housing_surface) ?></td>
        </tr>
        <tr>
            <td>Loyer :</td>
            <td><?php echo ($housing_rent) ?></td>
        </tr>
        <tr>
            <td>Disponible :</td>
            <td><?php echo ($housing_available) ?></td>
        </tr>
    </table>
    <a href="index.php">Afficher les logements</a>
</body>
</html>