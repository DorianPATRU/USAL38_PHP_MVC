DROP DATABASE IF EXISTS  mulhouse_habitat;

CREATE DATABASE IF NOT EXISTS mulhouse_habitat DEFAULT CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci';

USE mulhouse_habitat;

CREATE TABLE housing
(
	housing_type VARCHAR(20) NOT NULL,
    housing_postcode INT NOT NULL,
    housing_city VARCHAR(30) NOT NULL,
    housing_address VARCHAR(250) NOT NULL,
    housing_piecesnumber INT NOT NULL,
    housing_surface INT NOT NULL,
    housing_rent INT NOT NULL,
    housing_available VARCHAR(20) NOT NULL
);

INSERT INTO housing
(housing_type, housing_postcode, housing_city, housing_address, 
housing_piecesnumber, housing_surface, housing_rent, housing_available)
VALUES 
('Appartement', 68100, 'Mulhouse', '3 rue verte', 4, 80, 600, 'Oui'),
('Appartement', 68100, 'Mulhouse', '247 avenue du centre', 2, 50, 450, 'Non'),
('Maison', 68400, 'Riedisheim', '10 rue de Mulhouse', 5, 120, 900, 'Oui');


