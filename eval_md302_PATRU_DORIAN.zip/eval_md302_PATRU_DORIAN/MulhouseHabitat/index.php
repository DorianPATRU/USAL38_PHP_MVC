<?php

require_once("connexion.php");

$sql = "SELECT housing_type, housing_postcode, housing_city, housing_address, housing_piecesnumber, housing_surface, 
housing_rent, housing_available FROM housing";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Affichage des logements</title>
</head>
<link rel="stylesheet" href="style.css">
<body>
    <div class="content">
        <div class="border">
            <header>
                <h1>Mulhouse Habitat</h1>
                <img class="logo" src="logo_logement.jpg" alt="" />
            </header>
            <h2>Liste des logements en location</h2>
            <div class="tableau">
                <table border="1" width="80%">
                    <tr>
                        <th>Type de logement</th>
                        <th>Code postal</th>
                        <th>Ville </th>
                        <th>Adresse</th>
                        <th>Nombre de pièces</th>
                        <th>Surface</th>
                        <th>Loyer</th>
                        <th>Disponible</th>
                        <th>Actions</th>
                    </tr>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo ($row['housing_type']) ?></td>
                            <td><?php echo ($row['housing_postcode']) ?></td>
                            <td><?php echo ($row['housing_city']) ?></td>
                            <td><?php echo ($row['housing_address']) ?></td>
                            <td><?php echo ($row['housing_piecesnumber']) ?></td>
                            <td><?php echo ($row['housing_surface']) ?></td>
                            <td><?php echo ($row['housing_rent']) ?></td>
                            <td><?php echo ($row['housing_available']) ?></td>
                            <td><a href="">Editer </a>|
                            <a href="">Détails </a>|
                            <a href="">Supprimer </a></td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
