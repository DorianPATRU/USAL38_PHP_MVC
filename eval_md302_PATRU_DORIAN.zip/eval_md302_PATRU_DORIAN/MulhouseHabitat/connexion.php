<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mulhouse_habitat";
// Pour info, je n'ai pas mis de port car je n'en ai pas eu besoin sur ma machine lors des essais

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} else {
    //echo "Connection sucessful !";
}

